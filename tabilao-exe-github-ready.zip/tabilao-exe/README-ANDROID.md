# Tabilao Anjara — HTML → EXE amin'ny téléphone Android

Ity projet ity dia efa Electron. Ny téléphone Android dia ampiasaina handefasana azy any GitHub; GitHub Actions no manao ny compilation Windows `.exe`.

## Dingana amin'ny téléphone

1. Mamoròna repository vaovao ao GitHub, ohatra: `tabilao-anjara`.
2. Upload-nao ny zavatra rehetra ao amin'ity dossier `tabilao-exe` ity.
3. Ataovy ao amin'ny branch `main`.
4. Rehefa vita ny upload, mandehana amin'ny **Actions**.
5. Safidio **Build Tabilao Anjara EXE**.
6. Raha ilaina dia tsindrio **Run workflow**.
7. Rehefa vita, sokafy ilay workflow run ary tadiavo ny **Artifacts**.
8. Sintomy `Tabilao-Anjara-Windows.zip`; ao anatiny no misy `Tabilao-Anjara.exe`.

Tsy mila mametraka Node.js na Electron amin'ny Android ianao.
